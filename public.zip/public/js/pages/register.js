$(document).ready(function () {
    $(".login_backimg").backstretch([
        "/img/images/login2.png",
         "/img/images/login13.jpg",
         "/img/images/login10.png"
    ], {duration: 3000, fade: 750});
})

